const http = require('http');

const post = (path, data) => {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            }
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(body) }));
        });

        req.on('error', (e) => reject(e));
        req.write(data);
        req.end();
    });
};

const fs = require('fs');
const logFile = 'test_result.txt';
const log = (msg) => {
    console.log(msg);
    fs.appendFileSync(logFile, msg + '\n');
};

const run = async () => {
    fs.writeFileSync(logFile, '--- Starting Verification ---\n');
    const suffix = Date.now();
    const user = {
        username: `testuser_${suffix}`,
        email: `test_${suffix}@example.com`,
        password: 'password123'
    };

    log('--- Testing Registration ---');
    try {
        const regRes = await post('/auth/register', JSON.stringify(user));
        log(`Status: ${regRes.status}`);
        if (regRes.status !== 201) log('Registration failed');
        else log('Registration Success');
    } catch (e) {
        log(`Registration Error: ${e.message}`);
    }

    log('\n--- Testing Login ---');
    try {
        const loginRes = await post('/auth/login', JSON.stringify({ username: user.username, password: user.password }));
        log(`Status: ${loginRes.status}`);
        if (loginRes.status !== 200) log('Login failed');
        else log('Login Success');
    } catch (e) {
        log(`Login Error: ${e.message}`);
    }

    log('\n--- Testing Forgot Password ---');
    try {
        const forgotRes = await post('/auth/forgot-password', JSON.stringify({ email: user.email }));
        log(`Status: ${forgotRes.status}`);
        log(`Body: ${JSON.stringify(forgotRes.body)}`);
        if (forgotRes.status !== 200) log('Forgot Password failed');
        else log('Forgot Password Success (Mock Email Sent)');
    } catch (e) {
        log(`Forgot Password Error: ${e.message}`);
    }
};

run();
