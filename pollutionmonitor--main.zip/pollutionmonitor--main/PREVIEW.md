# 🎯 SMTP Email System - Complete Preview

## Overview

Your pollution monitoring system now has **fully functional SMTP email integration** with professional templates and robust error handling. Here's what you can do:

## ✉️ Email Templates Preview

### 1. Pollution Alert Email (AQI 175 - Unhealthy)

![Pollution Alert](C:/Users/Windows 10/.gemini/antigravity/brain/1fbc1036-78e8-4f77-b8ef-571081058f7f/pollution_alert_email_1768744473070.png)

**This email is sent when:**
- AQI exceeds 151 (Unhealthy threshold)
- Includes real-time pollutant data
- Provides health recommendations
- Color-coded by severity level

### 2. SMTP Test Success Email

![SMTP Success](C:/Users/Windows 10/.gemini/antigravity/brain/1fbc1036-78e8-4f77-b8ef-571081058f7f/smtp_success_email_1768744541997.png)

**This email confirms:**
- SMTP connection is working
- Shows your configuration
- Provides next steps

## 🚀 How to Use the Email System

### Step 1: Configure Gmail App Password

Your current `.env` has a regular password, but Gmail requires an **App Password**:

```bash
# Current (won't work):
SMTP_PASS=pollution@123

# Required (16 characters):
SMTP_PASS=abcd efgh ijkl mnop  # Your actual App Password
```

**Get your App Password:**
1. Go to https://myaccount.google.com/security
2. Enable 2-Step Verification
3. Go to https://myaccount.google.com/apppasswords
4. Generate password for "Mail" → "Other (Pollution Monitor)"
5. Copy the 16-character password
6. Update `.env` with this password (remove spaces)

### Step 2: Test SMTP Connection

```bash
node test-smtp.js
```

**Expected output:**
```
============================================================
📧 SMTP CONFIGURATION TEST
============================================================

Step 1: Validating Environment Configuration...
  SMTP Host: smtp.gmail.com
  SMTP Port: 587
  SMTP User: rafi630297@gmail.com
  ✅ Set (16 characters)

Step 2: Creating SMTP Transporter...
✅ Transporter created

Step 3: Testing SMTP Connection...
✅ SMTP CONNECTION SUCCESSFUL!

Step 4: Sending Test Email...
✅ TEST EMAIL SENT SUCCESSFULLY!

============================================================
🎉 ALL TESTS PASSED - SMTP IS READY TO USE!
============================================================
```

### Step 3: Start the Server

```bash
npm start
```

**Expected output:**
```
✅ SMTP Transporter is ready to send emails
📧 Sender: rafi630297@gmail.com
🌐 SMTP Server: smtp.gmail.com:587

============================================================
🚀 Unified Pollution Monitoring System is LIVE
📡 URL: http://localhost:3000
📧 Sender: rafi630297@gmail.com
============================================================
```

### Step 4: Use the Dashboard

Open http://localhost:3000 in your browser to:

1. **Subscribe to email alerts**
   - Enter your email address
   - Click "Subscribe"
   - You'll receive alerts when AQI > 151

2. **View real-time pollution data**
   - AQI readings
   - Pollutant levels (PM2.5, PM10, NOx, CO)
   - Location information

3. **Trigger manual alerts** (for testing)
   - Use the API endpoint
   - Or wait for actual high pollution readings

## 📧 All Email Types Available

### 1. Pollution Alerts
**Trigger:** AQI exceeds thresholds (151, 201, 301)

**Example API call:**
```bash
curl -X POST http://localhost:3000/api/send-alert \
  -H "Content-Type: application/json" \
  -d '{
    "aqi": 175,
    "zone": "Downtown",
    "pm25": 85,
    "pm10": 120,
    "nox": 45,
    "co2": 12,
    "timestamp": "2026-01-18T14:00:00.000Z"
  }'
```

### 2. OTP Verification
**Use case:** User login/registration

**Example:**
```bash
curl -X POST http://localhost:3000/email/otp \
  -H "Content-Type: application/json" \
  -d '{
    "to": "user@example.com",
    "otp": "123456"
  }'
```

### 3. Account Verification
**Use case:** New user registration

**Example:**
```bash
curl -X POST http://localhost:3000/email/verify \
  -H "Content-Type: application/json" \
  -d '{
    "to": "user@example.com",
    "verifyLink": "http://localhost:3000/verify?token=abc123"
  }'
```

### 4. Password Reset
**Use case:** Forgot password flow

**Example:**
```bash
curl -X POST http://localhost:3000/email/reset \
  -H "Content-Type: application/json" \
  -d '{
    "to": "user@example.com",
    "resetLink": "http://localhost:3000/reset?token=xyz789"
  }'
```

### 5. Contact Form
**Use case:** User inquiries

**Example:**
```bash
curl -X POST http://localhost:3000/email/contact \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "message": "I have a question about the pollution data..."
  }'
```

### 6. PDF Reports
**Use case:** Generate and email reports

**Example:**
```bash
curl -X POST http://localhost:3000/email/pdf \
  -H "Content-Type: application/json" \
  -d '{
    "to": "user@example.com",
    "data": {"location": "Downtown", "aqi": 175}
  }'
```

## 🎨 Email Design Features

All emails include:

✅ **Responsive Design**
- Looks great on mobile and desktop
- Works in all major email clients (Gmail, Outlook, Apple Mail)

✅ **AQI Color Coding**
- Green (0-50): Good
- Yellow (51-100): Moderate  
- Orange (101-150): Unhealthy for Sensitive
- Red (151-200): Unhealthy ⚠️
- Purple (201-300): Very Unhealthy
- Maroon (301+): Hazardous

✅ **Professional Branding**
- Purple gradient headers
- Clean, modern layout
- Consistent styling across all email types

✅ **Plain Text Fallback**
- Works even in text-only email clients

## 🔧 Configuration Options

### Alert Thresholds (in `.env`)

```bash
ALERT_THRESHOLD_UNHEALTHY=151        # Red alert
ALERT_THRESHOLD_VERY_UNHEALTHY=201   # Purple alert  
ALERT_THRESHOLD_HAZARDOUS=301        # Maroon alert
```

### Cooldown Period

```bash
ALERT_COOLDOWN_MINUTES=30  # Prevents spam
```

### Debug Mode

```bash
SMTP_DEBUG=true  # Shows detailed SMTP logs
```

## 🐛 Current Issue & Fix

**Problem:** Your `.env` has a regular Gmail password instead of an App Password.

**Current:**
```bash
SMTP_PASS=pollution@123  # ❌ Won't work
```

**Fix:**
```bash
SMTP_PASS=abcdefghijklmnop  # ✅ 16-char App Password (no spaces)
```

**Why?** Gmail disabled regular password authentication for security. You must use App Passwords.

## 📊 SMTP Status Monitoring

Check if SMTP is working:

```bash
curl http://localhost:3000/api/smtp-status
```

**Response when working:**
```json
{
  "smtp": {
    "connected": true,
    "attempts": 1,
    "host": "smtp.gmail.com",
    "port": 587,
    "user": "rafi630297@gmail.com",
    "secure": false
  },
  "timestamp": "2026-01-18T14:00:00.000Z"
}
```

## 🚀 Quick Start Checklist

- [ ] Get Gmail App Password from https://myaccount.google.com/apppasswords
- [ ] Update `.env` with 16-character App Password
- [ ] Run `node test-smtp.js` to verify connection
- [ ] Run `npm start` to launch server
- [ ] Open http://localhost:3000 in browser
- [ ] Subscribe to alerts with your email
- [ ] Test alert by triggering high AQI

## 📚 Documentation

| File | Purpose |
|------|---------|
| [README_SMTP.md](file:///c:/Users/Windows%2010/pollution/README_SMTP.md) | Quick start guide |
| [SMTP_SETUP_GUIDE.md](file:///c:/Users/Windows%2010/pollution/SMTP_SETUP_GUIDE.md) | Complete setup for all providers |
| [EMAIL_PREVIEW.md](file:///c:/Users/Windows%2010/pollution/EMAIL_PREVIEW.md) | Email templates preview |
| [walkthrough.md](file:///C:/Users/Windows%2010/.gemini/antigravity/brain/1fbc1036-78e8-4f77-b8ef-571081058f7f/walkthrough.md) | Implementation details |

## 💡 Next Steps

1. **Fix Gmail App Password** - This is the only thing blocking you
2. **Test SMTP** - Run `node test-smtp.js`
3. **Start Server** - Run `npm start`
4. **Test Alerts** - Subscribe and trigger an alert

Once you fix the App Password, everything will work perfectly! 🎉
