const emailService = require('../services/emailService');
const emailQueue = require('../utils/queue');
const subscriberStore = require('../utils/subscriberStore');

/**
 * Controller to handle incoming HTTP requests for emails
 */
const sendOTP = async (req, res) => {
    try {
        const { to, otp } = req.body;
        if (!to || !otp) return res.status(400).json({ success: false, message: 'Missing "to" or "otp"' });

        await emailService.sendOTP(to, otp);
        res.json({ success: true, message: 'OTP Email sent' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const sendVerification = async (req, res) => {
    try {
        const { to, verifyLink } = req.body;
        if (!to || !verifyLink) return res.status(400).json({ success: false, message: 'Missing "to" or "verifyLink"' });

        await emailService.sendVerification(to, verifyLink);
        res.json({ success: true, message: 'Verification Email sent' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const sendPasswordReset = async (req, res) => {
    try {
        const { to, resetLink } = req.body;
        if (!to || !resetLink) return res.status(400).json({ success: false, message: 'Missing "to" or "resetLink"' });

        await emailService.sendPasswordReset(to, resetLink);
        res.json({ success: true, message: 'Password Reset Email sent' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const sendAlert = async (req, res) => {
    try {
        const { to, sensorValue, aqiData } = req.body;

        // If aqiData is provided, it's a rich alert (likely from our monitor)
        if (aqiData) {
            const subscribers = to ? [to] : subscriberStore.getSubscribers();
            if (subscribers.length === 0) {
                return res.json({ success: true, message: 'No subscribers to alert' });
            }

            await emailService.sendBatchAlerts(subscribers, aqiData);
            return res.json({ success: true, message: `Alerts queued for ${subscribers.length} recipients` });
        }

        // Backward compatibility for basic sensorValue alerts
        if (!to || !sensorValue) return res.status(400).json({ success: false, message: 'Missing "to" or "sensorValue"' });

        // Create a simple aqiData object for the template
        const mockAqiData = {
            aqi: sensorValue,
            zone: 'Unknown Zone',
            pm25: sensorValue,
            pm10: sensorValue,
            nox: 0,
            co2: 0,
            timestamp: new Date().toISOString()
        };

        await emailService.sendPollutionAlert(to, mockAqiData);
        res.json({ success: true, message: 'Alert Email sent' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const subscribe = async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

        const result = subscriberStore.addSubscriber(email);
        res.json(result);
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const unsubscribe = async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

        const result = subscriberStore.removeSubscriber(email);
        res.json(result);
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const sendContact = async (req, res) => {
    try {
        const { name, email, message } = req.body;
        if (!name || !email || !message) return res.status(400).json({ success: false, message: 'Missing name, email, or message' });

        await emailService.sendContactForm(name, email, message);
        res.json({ success: true, message: 'Contact Form forwarded to admin' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const sendPDF = async (req, res) => {
    try {
        const { to, data } = req.body;
        if (!to) return res.status(400).json({ success: false, message: 'Missing "to" address' });

        await emailService.sendPDFAttachment(to, data);
        res.json({ success: true, message: 'PDF Email sent' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const sendBulk = async (req, res) => {
    try {
        const { emails, subject, message } = req.body;
        if (!emails || !Array.isArray(emails) || !subject || !message) {
            return res.status(400).json({ success: false, message: 'Invalid bulk email request format' });
        }

        emails.forEach(email => {
            emailQueue.enqueue(emailService.sendGenericEmail, { to: email, subject, message });
        });

        res.json({ success: true, message: `Bulk email process started for ${emails.length} recipients` });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

module.exports = {
    sendOTP,
    sendVerification,
    sendPasswordReset,
    sendAlert,
    sendContact,
    sendPDF,
    sendBulk,
    subscribe,
    unsubscribe
};
