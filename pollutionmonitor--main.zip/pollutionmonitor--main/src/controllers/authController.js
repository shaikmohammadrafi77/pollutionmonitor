const fs = require('fs');
const path = require('path');

const USERS_FILE = path.join(__dirname, '../../users.json');

// Helper to read users from file
const readUsers = () => {
    try {
        if (!fs.existsSync(USERS_FILE)) {
            return [];
        }
        const data = fs.readFileSync(USERS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading users file:', error);
        return [];
    }
};

// Helper to save users to file
const saveUsers = (users) => {
    try {
        fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
    } catch (error) {
        console.error('Error saving users file:', error);
    }
};

/**
 * Register a new user
 */
const register = (req, res) => {
    try {
        const { username, password, email } = req.body;

        if (!username || !password || !email) {
            return res.status(400).json({ success: false, message: 'All fields are required' });
        }

        const users = readUsers();

        // Check if user already exists
        if (users.find(u => u.username === username || u.email === email)) {
            return res.status(400).json({ success: false, message: 'User already exists' });
        }

        // Add new user (In production, passwords should be hashed!)
        const newUser = {
            id: Date.now(),
            username,
            password,
            email,
            createdAt: new Date().toISOString()
        };

        users.push(newUser);
        saveUsers(users);

        res.json({ success: true, message: 'Registration successful' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

/**
 * Login user
 */
const login = (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ success: false, message: 'Username and password are required' });
        }

        const users = readUsers();
        const user = users.find(u => u.username === username && u.password === password);

        if (!user) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        // Successful login
        res.json({
            success: true,
            message: 'Login successful',
            user: {
                id: user.id,
                username: user.username,
                email: user.email
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

module.exports = {
    register,
    login
};
