const bcrypt = require('bcryptjs');
const User = require('../models/User');

const register = async (username, email, password) => {
    // Check if user exists
    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
        throw new Error('User already exists');
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user
    const newUser = new User({
        username,
        email,
        password: hashedPassword
    });

    await newUser.save();
    return { success: true, message: 'User registered successfully' };
};

const login = async (username, password) => {
    // Find user
    const user = await User.findOne({ username });
    if (!user) {
        throw new Error('Invalid username or password');
    }

    // Validate password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
        throw new Error('Invalid username or password');
    }

    return { success: true, message: 'Login successful' };
};

const forgotPassword = async (email) => {
    const user = await User.findOne({ email });
    if (!user) {
        // Security: Don't reveal if user exists, but for this demo returns success
        return { success: true, message: 'If that email exists, a reset link has been sent.' };
    }

    // Generate a simple token (in production use styled JWT or crypto)
    const resetToken = Buffer.from(email + Date.now()).toString('base64');
    const resetLink = `http://localhost:3000/reset-password.html?token=${resetToken}`;

    // Use existing email service
    try {
        const emailService = require('./emailService');
        await emailService.sendPasswordReset(email, resetLink);
        return { success: true, message: 'Password reset link sent to your email.' };
    } catch (error) {
        console.error('Email send failed:', error);
        throw new Error('Failed to send password reset email.');
    }
};

module.exports = {
    register,
    login,
    forgotPassword
};
