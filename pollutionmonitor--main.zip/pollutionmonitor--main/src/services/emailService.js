const PDFDocument = require('pdfkit');
const { sendMail: sendEmail } = require('../config/mailConfig');

const VERIFIED_SENDER = process.env.SENDGRID_SENDER_EMAIL || process.env.FROM_EMAIL; // Use SendGrid sender

/**
 * Service to handle different email types
 */
class EmailService {
    /**
     * Send OTP Email
     */
    async sendOTP(to, otp) {
        const subject = 'Your Secure OTP';
        const text = `Your OTP is ${otp}`;
        const html = `
            <div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #eee;">
                <h2>Security Verification</h2>
                <p>Your One-Time Password (OTP) is:</p>
                <h1 style="color: #007bff; letter-spacing: 5px;">${otp}</h1>
                <p>This OTP is valid for 10 minutes.</p>
            </div>
        `;
        return await sendEmail(to, VERIFIED_SENDER, subject, text, html);
    }

    /**
     * Send Signup Verification
     */
    async sendVerification(to, verifyLink) {
        const subject = 'Verify Your Account';
        const text = `Verify your account using this link: ${verifyLink}`;
        const html = `
            <div style="font-family: Arial, sans-serif; padding: 20px;">
                <h2>Welcome!</h2>
                <p>Please click the button below to verify your account:</p>
                <a href="${verifyLink}" style="background-color: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Verify Account</a>
                <p>If the button doesn't work, copy-paste this link: ${verifyLink}</p>
            </div>
        `;
        return await sendEmail(to, VERIFIED_SENDER, subject, text, html);
    }

    /**
     * Send Password Reset
     */
    async sendPasswordReset(to, resetLink) {
        const subject = 'Reset Your Password';
        const text = `Reset your password using this link: ${resetLink}`;
        const html = `
            <div style="font-family: Arial, sans-serif; padding: 20px;">
                <h2>Password Reset Request</h2>
                <p>We received a request to reset your password. Click below to proceed:</p>
                <a href="${resetLink}" style="background-color: #dc3545; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Reset Password</a>
            </div>
        `;
        return await sendEmail(to, VERIFIED_SENDER, subject, text, html);
    }

    /**
     * Send IoT Pollution Alert
     */
    /**
     * Send professional Air Quality Alert
     */
    async sendPollutionAlert(to, aqiData) {
        const { aqi, zone, pm25, pm10, nox, co2, timestamp } = aqiData;
        const colors = this.getAQIColors(aqi);
        const { level, healthAdvice, icon } = this.getAQIInfo(aqi);

        const subject = `${icon} Air Quality Alert - ${level} (AQI: ${aqi})`;

        const html = `
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 20px auto; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border: 1px solid #eee; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }
        .alert-box { background: ${colors.bg}; color: ${colors.text}; padding: 25px; text-align: center; margin: 20px; border-radius: 10px; }
        .aqi-value { font-size: 54px; font-weight: bold; margin: 10px 0; }
        .content { padding: 30px; }
        .data-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .data-item { background: #f8f9fa; padding: 15px; border-radius: 8px; border-left: 4px solid #667eea; }
        .label { font-size: 12px; color: #666; text-transform: uppercase; font-weight: bold; }
        .value { font-size: 18px; font-weight: bold; color: #2c3e50; }
        .footer { background: #f1f3f5; padding: 20px; text-align: center; font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🌍 Smart City Monitor</h1>
            <p>Real-time Air Quality Notification</p>
        </div>
        <div class="alert-box">
            <div style="font-size: 20px; font-weight: 600;">${level}</div>
            <div class="aqi-value">${aqi}</div>
            <div style="font-size: 14px; opacity: 0.9;">Air Quality Index</div>
        </div>
        <div class="content">
            <h3 style="color: #2c3e50; border-bottom: 2px solid #667eea; padding-bottom: 10px;">🚨 Health Warning</h3>
            <p style="font-size: 16px;">${healthAdvice}</p>
            
            <h3 style="color: #2c3e50; margin-top: 30px;">📊 Pollutant Breakdown</h3>
            <div class="data-grid">
                <div class="data-item"><div class="label">PM2.5</div><div class="value">${pm25} µg/m³</div></div>
                <div class="data-item"><div class="label">PM10</div><div class="value">${pm10} µg/m³</div></div>
                <div class="data-item"><div class="label">NOx</div><div class="value">${nox} ppb</div></div>
                <div class="data-item"><div class="label">CO₂</div><div class="value">${co2} ppm</div></div>
            </div>
            
            <p style="font-size: 13px; color: #666; margin-top: 20px;">
                <strong>Location:</strong> ${zone}<br>
                <strong>Timestamp:</strong> ${new Date(timestamp).toLocaleString()}
            </p>
        </div>
        <div class="footer">
            <p>You received this because you subscribed to Air Quality Alerts for your zone.</p>
            <p>© 2026 Smart City Pollution Monitoring System</p>
        </div>
    </div>
</body>
</html>`;

        const text = `Air Quality Alert for ${zone}: AQI ${aqi} (${level}). ${healthAdvice}`;
        return await sendEmail(to, VERIFIED_SENDER, subject, text, html);
    }

    /**
     * Batch send alerts to multiple subscribers
     */
    async sendBatchAlerts(subscribers, aqiData) {
        if (!subscribers || subscribers.length === 0) return;

        console.log(`📧 Sending alerts to ${subscribers.length} subscribers...`);

        // Send all emails in parallel using Promise.all
        const emailPromises = subscribers.map(email =>
            this.sendPollutionAlert(email, aqiData).catch(err => {
                console.error(`❌ Failed to send alert to ${email}:`, err.message);
                return null; // Continue with other emails even if one fails
            })
        );

        const results = await Promise.all(emailPromises);
        const successCount = results.filter(r => r !== null).length;
        console.log(`✅ Successfully sent ${successCount}/${subscribers.length} alerts`);

        return results;
    }

    // Helper functions for template
    getAQIColors(aqi) {
        if (aqi >= 301) return { bg: '#7e0023', text: '#ffffff' }; // Hazardous
        if (aqi >= 201) return { bg: '#8f3f97', text: '#ffffff' }; // Very Unhealthy
        if (aqi >= 151) return { bg: '#ff0000', text: '#ffffff' }; // Unhealthy
        if (aqi >= 101) return { bg: '#ff9800', text: '#ffffff' }; // Unhealthy for Sensitive
        if (aqi >= 51) return { bg: '#ffeb3b', text: '#000000' }; // Moderate
        return { bg: '#4caf50', text: '#ffffff' }; // Good
    }

    getAQIInfo(aqi) {
        if (aqi >= 301) return { level: 'Hazardous', icon: '🟣', healthAdvice: '🚨 EMERGENCY: Everyone should avoid all physical activity outdoors.' };
        if (aqi >= 201) return { level: 'Very Unhealthy', icon: '🟣', healthAdvice: '⚠️ WARNING: Health alert: everyone may experience more serious health effects.' };
        if (aqi >= 151) return { level: 'Unhealthy', icon: '🔴', healthAdvice: '⚠️ CAUTION: Everyone may begin to experience health effects.' };
        if (aqi >= 101) return { level: 'Unhealthy for Sensitive Groups', icon: '🟠', healthAdvice: '⚠️ NOTICE: Members of sensitive groups may experience health effects.' };
        if (aqi >= 51) return { level: 'Moderate', icon: '🟡', healthAdvice: 'Air quality is acceptable.' };
        return { level: 'Good', icon: '🟢', healthAdvice: 'Air quality is satisfactory.' };
    }

    /**
     * Send Contact Form Submission (Forward to Admin)
     */
    async sendContactForm(name, email, message) {
        const subject = `New Contact Form Submission from ${name}`;
        const text = `Name: ${name}\nEmail: ${email}\nMessage: ${message}`;
        const html = `
            <div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ccc;">
                <h2>New Contact Form Submission</h2>
                <p><strong>Name:</strong> ${name}</p>
                <p><strong>Email:</strong> ${email}</p>
                <p><strong>Message:</strong></p>
                <p>${message}</p>
            </div>
        `;
        // Forward to admin (user's email)
        return await sendEmail(VERIFIED_SENDER, VERIFIED_SENDER, subject, text, html);
    }

    /**
     * Generate PDF and Send Attachment
     */
    async sendPDFAttachment(to, data) {
        return new Promise((resolve, reject) => {
            const doc = new PDFDocument();
            let buffers = [];
            doc.on('data', buffers.push.bind(buffers));
            doc.on('end', async () => {
                const pdfData = Buffer.concat(buffers);
                const attachments = [
                    {
                        content: pdfData.toString('base64'),
                        filename: 'Report.pdf',
                        type: 'application/pdf',
                        disposition: 'attachment'
                    }
                ];

                try {
                    const result = await sendEmail(to, VERIFIED_SENDER, 'Your PDF Report', 'Please find the attached report.', null, attachments);
                    resolve(result);
                } catch (error) {
                    reject(error);
                }
            });

            // Create PDF content
            doc.fontSize(25).text('Pollution Monitoring Report', 100, 80);
            doc.fontSize(12).text(`Generated on: ${new Date().toLocaleString()}`, 100, 120);
            doc.moveDown();
            doc.text(`Data: ${JSON.stringify(data, null, 2)}`);
            doc.end();
        });
    }

    /**
     * Generic bulk helper for queue
     */
    async sendGenericEmail(to, subject, message) {
        return await sendEmail(to, VERIFIED_SENDER, subject, message);
    }
}

module.exports = new EmailService();
