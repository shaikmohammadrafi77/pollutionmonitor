/**
 * ============================================
 * NODEMAILER CONFIGURATION (Production Ready)
 * ============================================
 * 
 * Unified SMTP transport for Gmail, SendGrid, Outlook, etc.
 * Maintains compatibility with existing emailService.js
 */

const nodemailer = require('nodemailer');
require('dotenv').config();

// 1. Create Transporter
// Priority: Custom SMTP > SendGrid (via SMTP) > Gmail (Default fallback)
const createTransporter = () => {

    // Option A: SendGrid via SMTP (If API Key is present)
    if (process.env.SENDGRID_API_KEY && !process.env.SMTP_HOST) {
        console.log('📧 Using SendGrid SMTP Transport');
        return nodemailer.createTransport({
            host: 'smtp.sendgrid.net',
            port: 587,
            secure: false, // true for 465, false for other ports
            auth: {
                user: 'apikey',
                pass: process.env.SENDGRID_API_KEY
            }
        });
    }

    // Option B: Standard SMTP (Gmail, Outlook, Custom)
    console.log('📧 Using Standard SMTP Transport');
    return nodemailer.createTransport({
        service: 'gmail', // Use built-in service shortcut for better compatibility
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
        }
    });
};

const transporter = createTransporter();

// Verify connection on startup
transporter.verify((error, success) => {
    if (error) {
        console.error('❌ SMTP Connection Error:', error.message);
    } else {
        console.log('✅ SMTP Server is ready to take our messages');
    }
});

/**
 * Send email using Nodemailer
 * @param {string} to - Recipient
 * @param {string} from - Sender (optional, uses env default)
 * @param {string} subject - Subject
 * @param {string} text - Plain text body
 * @param {string} html - HTML body
 */
const sendMail = async (to, from, subject, text, html) => {
    try {
        const mailOptions = {
            from: from || process.env.FROM_EMAIL || process.env.SMTP_USER,
            to: to,
            subject: subject,
            text: text,
            html: html
        };

        const info = await transporter.sendMail(mailOptions);
        console.log('✅ Message sent: %s', info.messageId);
        return { success: true, messageId: info.messageId };

    } catch (error) {
        console.error('❌ Error sending email:', error.message);
        throw error;
    }
};

module.exports = {
    sendMail,
    transporter // Exported for direct access if needed
};
