const mongoose = require('mongoose');

/**
 * MongoDB Connection Module
 * Handles connection to MongoDB Atlas using Mongoose with proper timeout and pool settings
 */
const connectDB = async () => {
    try {
        const useLocal = process.env.USE_LOCAL_DB === 'true';
        const dbUri = useLocal ? process.env.MONGODB_LOCAL : process.env.MONGODB_URI;
        const dbType = useLocal ? 'Local' : 'Cloud (Atlas)';

        console.log(`🔌 Attempting to connect to ${dbType} MongoDB...`);

        // Connection options to prevent timeouts and buffering issues
        const options = {
            serverSelectionTimeoutMS: 30000, // Increase timeout to 30 seconds
            socketTimeoutMS: 45000, // Socket timeout
            maxPoolSize: 10, // Maintain up to 10 connections in the pool
            minPoolSize: 2, // Maintain at least 2 connections
        };

        const conn = await mongoose.connect(dbUri, options);
        console.log(`✅ MongoDB Connected (${dbType}): ${conn.connection.host}`);

        // Handle connection errors after initial connection
        mongoose.connection.on('error', (err) => {
            console.error(`❌ MongoDB Connection Error: ${err.message}`);
        });

        mongoose.connection.on('disconnected', () => {
            console.warn(`⚠️ MongoDB Disconnected. Attempting to reconnect...`);
        });

        mongoose.connection.on('reconnected', () => {
            console.log(`✅ MongoDB Reconnected successfully`);
        });

    } catch (error) {
        console.error(`❌ MongoDB Connection Error: ${error.message}`);
        console.error(`💡 Make sure your IP is whitelisted in MongoDB Atlas`);
        console.warn(`⚠️  Server will continue running in PREVIEW MODE without database`);
        console.warn(`⚠️  Alert saving and data fetching will not work until MongoDB connects`);
        // Temporarily allow server to run for preview
        // process.exit(1); // Uncomment this after fixing MongoDB Atlas IP whitelist
    }
};

module.exports = connectDB;
