const { sendMail } = require('./mailConfig');

/**
 * Compatibility wrapper to send email via SMTP instead of SendGrid API
 * @param {string} to - Recipient email
 * @param {string} from - Verified sender email
 * @param {string} subject - Email subject
 * @param {string} text - Plain text content
 * @param {string} html - HTML content (optional)
 * @param {Array} attachments - PDF or other attachments (optional)
 */
const sendEmail = async (to, from, subject, text, html, attachments = []) => {
    try {
        return await sendMail(to, from, subject, text, html, attachments);
    } catch (error) {
        console.error('SMTP Wrapper Error:', error.message);
        throw error;
    }
};

module.exports = {
    // Mocking sgMail for compatibility if consumed elsewhere
    sgMail: {
        setApiKey: () => console.log('SendGrid API Key ignored (using SMTP)'),
        send: (msg) => sendMail(msg.to, msg.from, msg.subject, msg.text, msg.html, msg.attachments)
    },
    sendEmail
};
