const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const emailController = require('./controllers/emailController');
const authController = require('./controllers/authController');
const connectDB = require('./config/db');
const Alert = require('./models/Alert');
const PollutionData = require('./models/PollutionData');

// Load environment variables
require('dotenv').config();

// Pollution Monitoring Modules (from root)
const { generatePollutionData } = require('../dataSimulator');
const { predictAQI } = require('../model');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public')); // Serve the frontend dashboard

// Email Routes
app.post('/email/otp', emailController.sendOTP);
app.post('/email/verify', emailController.sendVerification);
app.post('/email/reset', emailController.sendPasswordReset);
app.post('/email/alert', emailController.sendAlert);
app.post('/email/contact', emailController.sendContact);
app.post('/email/pdf', emailController.sendPDF);
app.post('/email/bulk', emailController.sendBulk);

// --- New Subscription API Routes ---
app.post('/api/subscribe', emailController.subscribe);
app.post('/api/unsubscribe', emailController.unsubscribe);

// Feedback for GET requests to POST routes
const postOnlyRoutes = ['/email/otp', '/email/verify', '/email/reset', '/email/alert', '/email/contact', '/email/pdf', '/email/bulk', '/api/subscribe', '/api/unsubscribe'];
postOnlyRoutes.forEach(route => {
    app.get(route, (req, res) => {
        res.status(405).send(`
            <div style="font-family: sans-serif; padding: 20px; text-align: center;">
                <h1 style="color: #dc3545;">Method Not Allowed</h1>
                <p>The endpoint <code>${route}</code> only accepts <strong>POST</strong> requests.</p>
                <p>Please use the <a href="/index.html">Dashboard</a> to test this endpoint.</p>
            </div>
        `);
    });
});

// --- NEW MongoDB Auth Routes (Safe, Isolated) ---
app.use('/auth', require('./routes/authRoutes'));

// --- User Authentication Routes ---
app.post('/api/register', authController.register);
app.post('/api/login', authController.login);

// --- NEW Dashboard API Routes ---

// Track last alert time to prevent spam
let lastAlertTime = {};
const ALERT_COOLDOWN_MINUTES = process.env.ALERT_COOLDOWN_MINUTES || 30;
const ALERT_COOLDOWN_MS = ALERT_COOLDOWN_MINUTES * 60 * 1000;

/**
 * Main API endpoint for pollution prediction
 * GET /api/predict
 * Returns: Current AQI and pollutant levels
 */
app.get('/api/predict', async (req, res) => {
    try {
        // Generate simulated pollution sensor data
        const sensorData = generatePollutionData();

        // Use Hybrid CNN + ViT model to predict AQI
        const prediction = predictAQI(sensorData);

        // Combine sensor data with AI prediction
        const response = {
            aqi: prediction.aqi,
            status: prediction.status,
            pm25: sensorData.pm25,
            pm10: sensorData.pm10,
            co2: sensorData.co2,
            nox: sensorData.nox,
            zone: sensorData.zone,
            timestamp: new Date().toISOString()
        };

        // --- AUTOMATIC ALERT TRIGGER LOGIC ---
        const THRESHOLD = parseInt(process.env.ALERT_THRESHOLD_UNHEALTHY) || 151;
        if (response.aqi >= THRESHOLD) {
            const currentTime = Date.now();
            const locationKey = response.zone.toLowerCase().replace(/\s+/g, '_');

            // Check if cooldown is active
            if (!lastAlertTime[locationKey] || (currentTime - lastAlertTime[locationKey] >= ALERT_COOLDOWN_MS)) {
                console.log(`🚨 AQI ${response.aqi} exceeds threshold ${THRESHOLD} in ${response.zone}. Triggering alerts...`);

                // Trigger batch alerts via controller-like logic
                const subscriberStore = require('./utils/subscriberStore');
                const subscribers = subscriberStore.getSubscribers();

                if (subscribers.length > 0) {
                    const emailService = require('./services/emailService');
                    emailService.sendBatchAlerts(subscribers, response);
                    lastAlertTime[locationKey] = currentTime;
                    console.log(`✅ Automated batch alerts queued for ${subscribers.length} subscribers in ${response.zone}`);
                } else {
                    console.log(`ℹ️ No subscribers to alert for ${response.zone}`);
                }

                // --- SAVE ALERT TO MONGODB ---
                if (require('mongoose').connection.readyState === 1) {
                    try {
                        const newAlert = new Alert({
                            aqi: response.aqi,
                            status: response.status,
                            pm25: response.pm25,
                            pm10: response.pm10,
                            co2: response.co2,
                            nox: response.nox,
                            zone: response.zone,
                            timestamp: new Date(response.timestamp)
                        });
                        await newAlert.save();
                        console.log(`💾 Alert record saved to MongoDB for ${response.zone}`);
                    } catch (dbError) {
                        console.error(`❌ Failed to save alert record: ${dbError.message}`);
                    }
                } else {
                    console.log(`⚠️  Skipping database save (MongoDB not connected)`);
                }
            } else {
                const remainingMin = Math.ceil((ALERT_COOLDOWN_MS - (currentTime - lastAlertTime[locationKey])) / 60000);
                // Only log cooldown message once every 5 minutes per zone to reduce spam
                if (!lastAlertTime[locationKey + '_log'] || (currentTime - lastAlertTime[locationKey + '_log'] >= 5 * 60 * 1000)) {
                    console.log(`⏳ Alert cooldown active for ${response.zone}. Skipping alert. (${remainingMin} min remaining)`);
                    lastAlertTime[locationKey + '_log'] = currentTime;
                }
            }
        }

        // Log prediction in a clean format
        console.log(`Prediction generated: { aqi: ${response.aqi}, status: '${response.status}', zone: '${response.zone}', pm25: ${response.pm25} }`);

        res.json(response);
    } catch (error) {
        console.error('Error in /api/predict:', error);
        res.status(500).json({ error: 'Failed to generate prediction' });
    }
});

/**
 * API endpoint to fetch all saved alerts from MongoDB
 * GET /api/data
 */
app.get('/api/data', async (req, res) => {
    try {
        if (require('mongoose').connection.readyState !== 1) {
            return res.json({ message: 'MongoDB not connected - Preview mode', data: [] });
        }
        const alerts = await Alert.find().sort({ timestamp: -1 });
        res.json(alerts);
    } catch (error) {
        console.error('Error fetching alerts:', error);
        res.status(500).json({ error: 'Failed to fetch alert data' });
    }
});

/**
 * Health check endpoint
 * GET /api/health
 */
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        message: 'Hybrid ViT-CNN Pollution Detection System is running',
        timestamp: new Date().toISOString()
    });
});


// Start Server - Wait for DB connection first
(async () => {
    try {
        // Connect to MongoDB before starting server
        await connectDB();

        app.listen(PORT, () => {
            const url = `http://localhost:${PORT}`;
            console.log(`Server is running on http://localhost:${PORT}`);
            console.log('API Endpoints:');
            console.log(`- POST http://localhost:${PORT}/email/otp`);
            console.log(`- POST http://localhost:${PORT}/email/verify`);
            console.log(`- POST http://localhost:${PORT}/email/reset`);
            console.log(`- POST http://localhost:${PORT}/email/alert`);
            console.log(`- POST http://localhost:${PORT}/email/contact`);
            console.log(`- POST http://localhost:${PORT}/email/bulk`);

            console.log('\n🚀 Opening Dashboard automatically...');

            // Automatically open browser (Windows)
            const { exec } = require('child_process');
            setTimeout(() => {
                const startCommand = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'start' : 'xdg-open';
                exec(`${startCommand} ${url}`, (error) => {
                    if (error) {
                        console.log('⚠️  Could not open browser automatically.');
                        console.log(`   Please manually open: ${url}`);
                    }
                });
            }, 1000); // Wait 1 second for server to be ready

            // --- BACKGROUND DATA GENERATION ---
            // Automatically generate and save pollution data every 30 seconds
            setInterval(async () => {
                if (require('mongoose').connection.readyState === 1) {
                    try {
                        const sensorData = generatePollutionData();
                        const prediction = predictAQI(sensorData);

                        const pollutionRecord = new PollutionData({
                            aqi: prediction.aqi,
                            status: prediction.status,
                            pm25: sensorData.pm25,
                            pm10: sensorData.pm10,
                            co2: sensorData.co2,
                            nox: sensorData.nox,
                            zone: sensorData.zone,
                            timestamp: new Date()
                        });

                        await pollutionRecord.save();
                        console.log(`Prediction generated: { aqi: ${prediction.aqi}, status: '${prediction.status}', zone: '${sensorData.zone}', pm25: ${sensorData.pm25} }`);
                    } catch (error) {
                        console.error('Error saving pollution data:', error.message);
                    }
                }
            }, 30000); // Generate every 30 seconds (configurable)
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
})();

