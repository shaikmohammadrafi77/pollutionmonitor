const mongoose = require('mongoose');

const pollutionDataSchema = new mongoose.Schema({
    aqi: {
        type: Number,
        required: true
    },
    status: {
        type: String,
        required: true
    },
    pm25: {
        type: Number,
        required: true
    },
    pm10: {
        type: Number,
        required: true
    },
    co2: {
        type: Number,
        required: true
    },
    nox: {
        type: Number,
        required: true
    },
    zone: {
        type: String,
        required: true
    },
    timestamp: {
        type: Date,
        default: Date.now
    }
});

const PollutionData = mongoose.model('PollutionData', pollutionDataSchema);

module.exports = PollutionData;
