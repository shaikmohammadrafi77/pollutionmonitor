const mongoose = require('mongoose');

const alertSchema = new mongoose.Schema({
    aqi: {
        type: Number,
        required: true
    },
    status: {
        type: String,
        required: true
    },
    pm25: Number,
    pm10: Number,
    co2: Number,
    nox: Number,
    zone: {
        type: String,
        required: true
    },
    timestamp: {
        type: Date,
        default: Date.now
    }
});

const Alert = mongoose.model('Alert', alertSchema);

module.exports = Alert;
