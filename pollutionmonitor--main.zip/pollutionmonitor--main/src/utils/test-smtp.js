const { verifyConnection, sendMail } = require('../config/mailConfig');
require('dotenv').config();

async function runTest() {
    console.log('🚀 Starting SMTP Test...');

    // 1. Verify connection
    const isConnected = await verifyConnection();
    if (!isConnected) {
        console.error('❌ SMTP Connection failed. Please check your credentials in .env');
        process.exit(1);
    }

    // 2. Try sending a test email
    const testRecipient = process.env.FROM_EMAIL || 'rafi630297@gmail.com';
    console.log(`📧 Attempting to send test email to: ${testRecipient}...`);

    try {
        const result = await sendMail(
            testRecipient,
            null, // uses default from .env
            'SMTP Integration Test',
            'This is a test email from the Pollution Monitoring System using SMTP.',
            '<h1>SMTP Test Success</h1><p>Your SMTP integration is working correctly!</p>'
        );

        if (result.success) {
            console.log('✅ Test email sent successfully!');
            console.log('Message ID:', result.messageId);
        }
    } catch (error) {
        console.error('❌ Failed to send test email:', error.message);
    }
}

runTest();
