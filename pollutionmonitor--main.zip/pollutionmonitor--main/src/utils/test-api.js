const http = require('http');

function checkEndpoint(path) {
    return new Promise((resolve, reject) => {
        const req = http.get(`http://localhost:3000${path}`, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                try {
                    console.log(`\nEndpoint: ${path}`);
                    console.log(`Status: ${res.statusCode}`);
                    const json = JSON.parse(data);
                    console.log('Response:', JSON.stringify(json, null, 2));
                    resolve(json);
                } catch (e) {
                    console.error('Error parsing JSON:', e);
                    reject(e);
                }
            });
        });
        req.on('error', (e) => {
            console.error(`Request failed: ${path}`, e.message);
            reject(e);
        });
    });
}

async function runTests() {
    try {
        console.log('--- Testing API Endpoints ---');
        await checkEndpoint('/api/health');
        await checkEndpoint('/api/predict');
        console.log('\n✅ API Tests Completed');
    } catch (e) {
        console.error('\n❌ API Tests Failed. Is the server running?');
    }
}

runTests();
