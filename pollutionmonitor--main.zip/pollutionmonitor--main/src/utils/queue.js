/**
 * Simple Queue with Retry logic
 * Beginner friendly implementation using an array
 */
class SimpleQueue {
    constructor(maxRetries = 3) {
        this.queue = [];
        this.processing = false;
        this.maxRetries = maxRetries;
    }

    /**
     * Add a task to the queue
     * @param {Function} taskFn - The function to execute (must return a promise)
     * @param {Object} context - Data to pass to the taskFn
     */
    enqueue(taskFn, context) {
        this.queue.push({ taskFn, context, retries: 0 });
        this.process();
    }

    async process() {
        if (this.processing || this.queue.length === 0) return;

        this.processing = true;
        const task = this.queue.shift();

        try {
            await task.taskFn(task.context);
            console.log('Task completed successfully');
        } catch (error) {
            console.error(`Task failed (Attempt ${task.retries + 1}):`, error.message);

            if (task.retries < this.maxRetries) {
                task.retries++;
                // Re-enqueue at the end
                this.queue.push(task);
                console.log(`Re-queued for retry ${task.retries}`);
            } else {
                console.error('Max retries reached. Task dropped.');
            }
        }

        this.processing = false;
        // Process next item in the next event loop tick
        setImmediate(() => this.process());
    }
}

const emailQueue = new SimpleQueue(3);

module.exports = emailQueue;
