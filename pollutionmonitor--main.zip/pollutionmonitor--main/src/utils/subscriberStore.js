const fs = require('fs');
const path = require('path');

const SUBSCRIBERS_FILE = path.join(__dirname, '../../subscribers.json');

/**
 * Utility to manage subscriber email persistence
 */
class SubscriberStore {
    constructor() {
        this.subscribers = this.loadSubscribers();
    }

    loadSubscribers() {
        try {
            if (fs.existsSync(SUBSCRIBERS_FILE)) {
                const data = fs.readFileSync(SUBSCRIBERS_FILE, 'utf8');
                return JSON.parse(data);
            }
        } catch (error) {
            console.error('❌ Error loading subscribers:', error.message);
        }
        return [];
    }

    saveSubscribers() {
        try {
            fs.writeFileSync(SUBSCRIBERS_FILE, JSON.stringify(this.subscribers, null, 2));
            return true;
        } catch (error) {
            console.error('❌ Error saving subscribers:', error.message);
            return false;
        }
    }

    getSubscribers() {
        return this.subscribers;
    }

    addSubscriber(email) {
        const normalizedEmail = email.toLowerCase().trim();
        if (this.subscribers.includes(normalizedEmail)) {
            return { success: true, message: 'Already subscribed', email: normalizedEmail };
        }

        this.subscribers.push(normalizedEmail);
        if (this.saveSubscribers()) {
            return { success: true, message: 'Subscribed successfully', email: normalizedEmail };
        }
        return { success: false, message: 'Failed to save subscription' };
    }

    removeSubscriber(email) {
        const normalizedEmail = email.toLowerCase().trim();
        const index = this.subscribers.indexOf(normalizedEmail);

        if (index === -1) {
            return { success: false, message: 'Email not found in subscribers list' };
        }

        this.subscribers.splice(index, 1);
        if (this.saveSubscribers()) {
            return { success: true, message: 'Unsubscribed successfully', email: normalizedEmail };
        }
        return { success: false, message: 'Failed to save unsubscription' };
    }
}

module.exports = new SubscriberStore();
