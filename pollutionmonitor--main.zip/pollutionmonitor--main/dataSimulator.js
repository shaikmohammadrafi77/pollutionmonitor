/**
 * Pollution Data Simulator
 * 
 * WHY SIMULATED DATA?
 * - No physical sensors available for academic project
 * - Simulates realistic pollution patterns
 * - Generates data that varies over time
 * - Safe for demonstration and exams
 * 
 * This module generates realistic pollution sensor readings
 * that mimic real-world air quality monitoring stations.
 */

// Zone configurations (different areas have different pollution levels)
// Zone configurations (different areas have different pollution levels)
const zones = [
    { name: 'Industrial Zone', basePM25: 120, basePM10: 150, baseNOx: 80, baseCO2: 500 },
    { name: 'City Center', basePM25: 85, basePM10: 120, baseNOx: 65, baseCO2: 450 },
    { name: 'Residential Area', basePM25: 45, basePM10: 65, baseNOx: 30, baseCO2: 410 },
    { name: 'Green Park', basePM25: 25, basePM10: 35, baseNOx: 10, baseCO2: 380 },
    { name: 'Highway', basePM25: 75, basePM10: 95, baseNOx: 70, baseCO2: 460 }
];

/**
 * Generates realistic pollution data for a random zone
 * Simulates natural variations in air quality
 * 
 * @returns {Object} - Simulated sensor readings
 */
function generatePollutionData() {
    // Randomly select a zone
    const zone = zones[Math.floor(Math.random() * zones.length)];

    // Generate time-based variation (pollution changes throughout the day)
    const hour = new Date().getHours();
    let timeMultiplier = 1.0;

    // Higher pollution during rush hours (8-10 AM, 5-7 PM)
    if ((hour >= 8 && hour <= 10) || (hour >= 17 && hour <= 19)) {
        timeMultiplier = 1.3; // 30% higher during rush hours
    } else if (hour >= 22 || hour <= 6) {
        timeMultiplier = 0.8; // 20% lower at night
    }

    // Add random variation (±20%) to simulate real sensor fluctuations
    const variation = () => 0.8 + (Math.random() * 0.4); // Random between 0.8 and 1.2

    // Generate pollutant values with realistic variations
    const pm25 = Math.round(zone.basePM25 * timeMultiplier * variation());
    const pm10 = Math.round(zone.basePM10 * timeMultiplier * variation());
    const nox = Math.round(zone.baseNOx * timeMultiplier * variation());
    const co2 = Math.round(zone.baseCO2 + (Math.random() * 40 - 20)); // CO2 varies less

    return {
        pm25: Math.max(5, pm25),      // Minimum 5 µg/m³
        pm10: Math.max(10, pm10),     // Minimum 10 µg/m³
        nox: Math.max(5, nox),        // Minimum 5 ppb
        co2: Math.max(380, co2),      // Minimum 380 ppm (natural baseline)
        zone: zone.name,
        timestamp: new Date().toISOString()
    };
}

/**
 * Generates historical data for charts (last N days)
 * Used for trend visualization
 * 
 * @param {number} days - Number of days of historical data
 * @returns {Array} - Array of historical pollution readings
 */
function generateHistoricalData(days = 7) {
    const data = [];
    const now = new Date();

    for (let i = days; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(date.getDate() - i);

        // Generate data for each day
        for (let hour = 0; hour < 24; hour += 2) { // Every 2 hours
            const reading = generatePollutionData();
            reading.timestamp = new Date(date.setHours(hour)).toISOString();
            data.push(reading);
        }
    }

    return data;
}

// Export functions
module.exports = {
    generatePollutionData,
    generateHistoricalData,
    zones
};
