const mongoose = require('mongoose');
const fs = require('fs');
require('dotenv').config();
const User = require('./src/models/User');

const log = (msg) => {
    console.log(msg);
    fs.appendFileSync('db_check_result.txt', msg + '\n');
};

const checkUser = async () => {
    try {
        fs.writeFileSync('db_check_result.txt', '--- Starting DB Check ---\n');
        await mongoose.connect(process.env.MONGODB_URI);
        log('Connected to DB');

        const email = 'sweetkiller281@gmail.com';
        const user = await User.findOne({ email });

        if (user) {
            log(`✅ User found: ${user.username} (${user.email})`);
        } else {
            log(`❌ User with email ${email} NOT FOUND.`);
            log('This explains why no email was sent (security feature hides non-existence).');
        }

    } catch (error) {
        log(`Error: ${error.message}`);
    } finally {
        await mongoose.disconnect();
        process.exit();
    }
};

checkUser();
