# PROJECT OVERVIEW: City Pollution Monitoring & Alert Dashboard

## 1. Executive Summary
### Problem Statement
Rapid urbanization and industrialization have led to a significant increase in atmospheric pollutants (PM2.5, PM10, NOx, CO₂), posing severe health risks to urban populations. Conventional monitoring systems often lack real-time predictive capabilities and automated public alert mechanisms.

### Objective
To develop an intelligent, real-time "Smart City" dashboard that monitors air quality, predicts Air Quality Index (AQI) using a Hybrid AI model, and provides automated health alerts to citizens and administrators.

### Solution
The **City Pollution Monitoring Dashboard** is a full-stack solution integrating real-time data simulation, a **Hybrid CNN + Vision Transformer (ViT)** AI model for prediction, and an automated notification system. It provides high-precision data visualization via interactive maps and analytics charts.

### Real-World Use Cases
- **Public Health**: Citizens receive alerts to limit outdoor activity during "Critical" AQI periods.
- **Urban Planning**: Government bodies can identify high-pollution zones for traffic rerouting or greening.
- **Academic Research**: Provides historical datasets for studying long-term environmental trends.

### Target Users
- **Citizens**: To monitor local air quality and receive health advice.
- **Government Agencies**: For environment monitoring and emergency broadcasts.
- **Researchers**: To analyze pollution trends and AI model accuracy.

---

## 2. Artificial Intelligence Components
The core intelligence of the system relies on a **Hybrid AI Architecture** to ensure both local sensitivity and global accuracy.

### Type of AI/ML Used
- **Convolutional Neural Network (CNN)**: Used for local feature extraction (detecting immediate pollutant spikes).
- **Vision Transformer (ViT)**: Used for global trend analysis and situational awareness (understanding city-wide patterns).
- **Decision Classification**: For categorizing the final prediction into health-risk levels (Good, Moderate, Unhealthy, Critical).

### Why AI is Needed
Traditional AQI calculations are purely mathematical and reactive. AI adds **predictive intelligence**, allowing the system to learn patterns from multiple pollutants and geographic contexts to forecast air quality more accurately.

### AI Prediction Logic (Fusion Approach)
1. **Data Preprocessing**: Raw sensor data (µg/m³, ppb, ppm) is normalized to a standard numeric scale.
2. **Feature Extraction (CNN)**: The CNN branch analyzes immediate pollutant levels (PM2.5, PM10) to catch rapid local changes.
3. **Global Attention (ViT)**: The ViT branch analyzes the "Global Context"—how pollution in one zone (e.g., Highway) might affect another (Residential).
4. **Weighted Fusion**:
   - `Final AQI = (CNN_Score × 0.6) + (ViT_Score × 0.4)`
5. **Classification**: The final score is mapped to standard AQI categories using a threshold-based classifier.

---

## 3. API Documentation
The system follows a modular API-first architecture. All internal endpoints reside under the base address: `http://localhost:3000/api/`

### Internal API Endpoints
| API Name | Method | Full Address / Endpoint | Purpose |
| :--- | :--- | :--- | :--- |
| **<span style="color: blue;">Pollution Predictor</span>** | GET | `http://localhost:3000/api/predict` | Returns real-time sensor data and AI-predicted AQI. |
| **<span style="color: blue;">User Login</span>** | POST | `http://localhost:3000/api/login` | Authenticates users and grants dashboard access. |
| **<span style="color: blue;">User Register</span>** | POST | `http://localhost:3000/api/register` | Creates new user accounts. |
| **<span style="color: blue;">Alert Subscription</span>** | POST | `http://localhost:3000/api/subscribe` | Adds user email to the automated alert queue. |
| **<span style="color: blue;">System Health</span>** | GET | `http://localhost:3000/api/health` | Returns server status and AI model version. |
| **<span style="color: blue;">Email Alert Service</span>** | POST | `http://localhost:3000/email/alert` | Triggers a real-time notification to subscribers. |

### External API Data Providers
These third-party APIs are integrated for real-time geolocation and environmental data.

| Provider | Purpose | Base API Address |
| :--- | :--- | :--- |
| **Open-Meteo** | Air Quality Data | `https://air-quality-api.open-meteo.com/v1/air-quality` |
| **OpenStreetMap** | Geocoding (Search) | `https://nominatim.openstreetmap.org/search` |
| **Leaflet** | Interactive Maps | `https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png` |


### Prediction API Response Format (JSON)
```json
{
  "aqi": 185,
  "status": "CRITICAL",
  "pm25": 142,
  "pm10": 178,
  "zone": "Industrial Zone",
  "timestamp": "2026-01-21T07:30:00Z"
}
```

---

## 4. AI Workflow Explanation
1. **Data Collection**: The backend fetches real-time data from sensors (or the `dataSimulator` in the demo environment).
2. **Preprocessing**: Data is normalized and passed to the `predictAQI` module.
3. **AI Processing**:
   - The **CNN Branch** extracts local pollution features.
   - The **ViT Branch** applies attention weights based on the city zone.
   - The **Fusion Layer** calculates the combined prediction.
4. **Alert Generation**: If the predicted AQI > 150 (Unhealthy), a trigger is sent to the `emailService`.
5. **UI Display**: The frontend (Leaflet maps and Charts) updates every 30 seconds to reflect the new AI results.

---

## 5. System Architecture
- **Frontend**: Single Page Application (SPA) built with HTML5, Vanilla JavaScript, and CSS Grid/Flexbox.
  - *Visualization Libraries*: Leaflet.js (Maps), Canvas (Charts).
- **Backend**: Node.js with Express.js framework.
- **AI/ML Stack**: Custom Hybrid Model logic implemented in JavaScript within `model.js`.
- **Database**: MongoDB for storing alert logs and user credentials.
- **Communications**: RESTful API calls and SMTP for email alerts.

---

## 6. Project File Structure
```text
pollution/
├── public/                 # Frontend Assets
│   ├── index.html          # Main Dashboard
│   └── css/                # Layout & Designs
├── src/                    # Backend Source
│   ├── controllers/        # Auth & Email Logic
│   ├── models/             # MongoDB Schemas
│   ├── config/             # Database & SMTP Config
│   └── server.js           # Main Entry Point
├── ai-model/               # AI Components
│   ├── model.js            # Hybrid CNN-ViT Logic
│   └── dataSimulator.js    # Sensor Data Engine
├── docs/                   # Documentation
│   └── PROJECT_OVERVIEW.md # Project Doc
├── .env                    # Secrets & API Keys
└── package.json            # Dependencies
```

---

## 7. Conclusion
This dashboard represents a state-of-the-art solution for environmental monitoring. By leveraging a **Hybrid CNN + ViT** approach, it provides a highly reliable and user-friendly system suitable for smart-city implementations. Its automated alert mechanisms bridge the gap between complex AI predictions and actionable public safety.
