const http = require('http');
const fs = require('fs');

const log = (msg) => {
    console.log(msg);
    fs.appendFileSync('repro_result.txt', msg + '\n');
};

const post = (path, data) => {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            }
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(body) }));
        });

        req.on('error', (e) => reject(e));
        req.write(data);
        req.end();
    });
};

const run = async () => {
    fs.writeFileSync('repro_result.txt', '--- Starting --- \n');
    const user = {
        username: 'rafi',
        email: 'sweetkiller281@gmail.com',
        password: 'password123'
    };

    log(`Attempting to register: ${user.username} / ${user.email}`);
    try {
        const res = await post('/auth/register', JSON.stringify(user));
        log(`Status: ${res.status}`);
        log(`Response: ${JSON.stringify(res.body)}`);
    } catch (e) {
        log(`Error: ${e.message}`);
    }
};

run();
