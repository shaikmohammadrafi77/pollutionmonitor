# Hybrid ViT–CNN for Robust Air Pollution Detection and Analysis

## MCA Final Year Major Project

A complete full-stack web application for real-time air pollution monitoring using a conceptual Hybrid CNN + Vision Transformer (ViT) AI model.

---

## 📋 Project Overview

This project demonstrates a **Smart City Air Pollution Monitoring System** that:
- Uses **Hybrid AI Model** (CNN + ViT) for AQI prediction
- Displays real-time pollution data on a modern dashboard
- Simulates realistic sensor data (no physical sensors required)
- Provides RESTful API for data access

---

pollution/
├── public/
│   └── index.html          # Frontend UI (HTML + CSS + JavaScript)
├── src/
│   ├── server.js           # Express server & API endpoints
│   ├── controllers/        # Logic handlers
│   ├── models/             # Database schemas
│   └── config/             # Configuration files
├── ai-model/
│   ├── model.js            # Hybrid CNN + ViT AI model simulation
│   └── dataSimulator.js    # Pollution data generator
├── package.json            # Node.js dependencies
├── .env                    # Environment variables
├── KILL_PORT.bat           # Port reset utility
└── README.md               # This file
```

---

## 🚀 Quick Start Guide

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Prepare & Start the Server
If you are restarting the server or find the port busy, run:
```powershell
.\KILL_PORT.bat
```

Then start the application:
```bash
npm start
```

### Step 3: Open in Browser
Open your browser and go to:
```
http://localhost:3000
```

The dashboard will automatically update every 5 seconds with new pollution data.

---

## 📁 File Descriptions

### 1. `public/index.html`
- **Purpose**: Frontend dashboard UI
- **Contains**: HTML structure, CSS styles, and JavaScript for dynamic updates
- **Features**: 
  - Real-time AQI display
  - Pollutant cards (PM2.5, PM10, CO2, NOx)
  - Auto-refresh every 5 seconds
  - Responsive design

### 2. `server.js`
- **Purpose**: Express.js backend server
- **Features**:
  - REST API endpoint: `/api/predict` (returns pollution data)
  - Health check: `/api/health`
  - Serves static files from `public/` folder
  - Runs on port 3000

### 3. `model.js`
- **Purpose**: Hybrid CNN + ViT AI model simulation
- **How it works**:
  - **CNN**: Analyzes local pollution patterns (60% weight)
  - **ViT**: Analyzes global city-wide trends (40% weight)
  - **Fusion**: Combines both predictions for final AQI
- **Output**: AQI value (0-300) and status category

### 4. `dataSimulator.js`
- **Purpose**: Generates realistic simulated pollution data
- **Features**:
  - Simulates 5 different zones (Industrial, City Center, Residential, Green Park, Highway)
  - Time-based variations (rush hour = higher pollution)
  - Random fluctuations (±20%) for realism
- **Why simulated?**: No physical sensors available for academic project

### 5. `package.json`
- **Purpose**: Node.js project configuration
- **Dependencies**: Express.js, CORS

---

## 🧠 AI Model Explanation (For Viva)

### Why CNN?
- **CNN (Convolutional Neural Network)** detects **local patterns**
- Like recognizing nearby pollution sources (factories, traffic)
- Good for detecting sudden spikes in pollution
- Simulates feature extraction from sensor data

### Why ViT?
- **ViT (Vision Transformer)** analyzes **global trends**
- Like understanding city-wide pollution patterns
- Good for long-term trend analysis
- Simulates attention mechanism across zones

### Why Hybrid?
- **Combines best of both**: Local (CNN) + Global (ViT)
- More accurate than using either alone
- CNN weight: 60% (immediate detection)
- ViT weight: 40% (global context)

### How It Works:
1. **Input**: Sensor readings (PM2.5, PM10, CO2, NOx)
2. **CNN Processing**: Analyzes local features → Score A
3. **ViT Processing**: Analyzes global trends → Score B
4. **Fusion**: Final AQI = (A × 0.6) + (B × 0.4)
5. **Output**: AQI value and status (GOOD/MODERATE/UNHEALTHY/CRITICAL)

---

## 🔌 API Endpoints

### GET `/api/predict`
Returns current pollution data and AQI prediction.

**Response:**
```json
{
  "aqi": 156,
  "status": "UNHEALTHY",
  "pm25": 85,
  "pm10": 110,
  "co2": 420,
  "nox": 45,
  "zone": "Industrial Area",
  "timestamp": "2026-01-12T10:30:00.000Z"
}
```

### GET `/api/health`
Server health check endpoint.

---

## 🎨 Dashboard Features

- **Real-time AQI Display**: Updates automatically every 5 seconds
- **Pollutant Cards**: Shows PM2.5, PM10, CO2, NOx levels
- **Color-coded Status**: Green (Good) → Yellow (Moderate) → Orange (Unhealthy) → Red (Critical)
- **Alerts Section**: Shows active pollution alerts
- **Sensor Table**: Displays sensor status overview
- **Responsive Design**: Works on desktop, tablet, and mobile

---

## 🛠️ Technologies Used

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Node.js, Express.js
- **AI Model**: Conceptual Hybrid CNN + ViT (simulated)
- **Data**: Simulated sensor data (no external APIs)

---

## 📝 Notes for Viva Presentation

1. **Why Simulated Data?**
   - No physical sensors available for academic project
   - Simulates realistic pollution patterns
   - Safe for demonstration

2. **Why Hybrid Model?**
   - CNN catches local patterns (sudden spikes)
   - ViT catches global trends (long-term patterns)
   - Combined = more accurate predictions

3. **System Architecture:**
   - Frontend: HTML/CSS/JS dashboard
   - Backend: Node.js + Express REST API
   - AI: Hybrid CNN + ViT model
   - Data: Simulated sensor readings

---

## ✅ Testing Checklist

- [ ] Run `npm install`
- [ ] Start server: `node server.js`
- [ ] Open `http://localhost:3000`
- [ ] Check if dashboard loads
- [ ] Verify data updates every 5 seconds
- [ ] Test API: `http://localhost:3000/api/predict`
- [ ] Check console for any errors

---

## 🐛 Troubleshooting

**Problem**: Server won't start
- **Solution**: Make sure port 3000 is not in use. You can run the provided script to force close the port:
  ```powershell
  .\KILL_PORT.bat
  ```

**Problem**: Dashboard shows "Unable to fetch data"
- **Solution**: Ensure server is running (`node server.js`)

**Problem**: Data not updating
- **Solution**: Check browser console for errors, verify API endpoint

---

## 📞 Support

For questions or issues, check:
1. Server console logs
2. Browser developer console (F12)
3. API endpoint responses

---

## 📄 License

Academic Project - MCA Final Year




