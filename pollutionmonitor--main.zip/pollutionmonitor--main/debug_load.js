console.log('Hello from test');
require('./src/services/authService');
console.log('Service loaded');
const authRoutes = require('./src/routes/authRoutes');
console.log('Routes loaded');
