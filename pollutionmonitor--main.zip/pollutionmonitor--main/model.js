/**
 * Hybrid CNN + Vision Transformer (ViT) Model Simulation
 * 
 * CONCEPTUAL EXPLANATION:
 * 
 * CNN (Convolutional Neural Network):
 * - Simulates LOCAL feature detection (nearby pollution sources)
 * - Analyzes patterns in immediate sensor readings
 * - Good for detecting sudden spikes in pollution
 * 
 * Vision Transformer (ViT):
 * - Simulates GLOBAL trend analysis (city-wide patterns)
 * - Analyzes long-term pollution trends across zones
 * - Good for understanding overall air quality patterns
 * 
 * FUSION:
 * - Combines CNN (local) + ViT (global) predictions
 * - Final AQI = weighted average of both predictions
 * - This hybrid approach gives more accurate results
 */

/**
 * Simulates CNN processing for local pollution features
 * CNN detects patterns in nearby sensor readings
 * 
 * @param {Object} sensorData - Current sensor readings
 * @returns {number} - CNN prediction score (0-300)
 */
function cnnPrediction(sensorData) {
    // CNN focuses on LOCAL patterns (immediate area)
    // Simulates feature extraction from sensor data

    // Weight factors for different pollutants (CNN learns these patterns)
    const weights = {
        pm25: 0.35,  // PM2.5 is most critical
        pm10: 0.25,  // PM10 is also important
        nox: 0.25,   // NOx from vehicles
        co2: 0.15    // CO2 baseline
    };

    // Normalize values to 0-300 scale
    const pm25Score = (sensorData.pm25 / 150) * 300;
    const pm10Score = (sensorData.pm10 / 200) * 300;
    const noxScore = (sensorData.nox / 100) * 300;
    const co2Score = ((sensorData.co2 - 400) / 200) * 300;

    // CNN combines features (weighted sum)
    const cnnOutput =
        (pm25Score * weights.pm25) +
        (pm10Score * weights.pm10) +
        (noxScore * weights.nox) +
        (co2Score * weights.co2);

    // Add some noise to simulate CNN's pattern recognition
    const noise = (Math.random() - 0.5) * 10;

    return Math.max(0, Math.min(300, cnnOutput + noise));
}

/**
 * Simulates Vision Transformer (ViT) processing for global trends
 * ViT analyzes city-wide pollution patterns over time
 * 
 * @param {Object} sensorData - Current sensor readings
 * @returns {number} - ViT prediction score (0-300)
 */
function vitPrediction(sensorData) {
    // ViT focuses on GLOBAL patterns (city-wide trends)
    // Simulates attention mechanism across different zones

    // Zone-based weighting (ViT learns global patterns)
    const zoneWeights = {
        'Tomato Market Yard': 1.1,        // Dust and commercial activity
        'Gandhi Circle (City Center)': 1.2, // High traffic
        'Besant Nagar (Residential)': 0.9,  // Moderate
        'Rishi Valley (Green Zone)': 0.6,   // Very clean air
        'CTR-KPT Highway Junction': 1.4     // Heavy vehicle pollution
    };

    const zoneMultiplier = zoneWeights[sensorData.zone] || 1.0;

    // ViT analyzes global trends (average across all pollutants)
    const averagePollution = (
        (sensorData.pm25 / 150) +
        (sensorData.pm10 / 200) +
        (sensorData.nox / 100) +
        ((sensorData.co2 - 400) / 200)
    ) / 4;

    // Apply global zone context
    const vitOutput = averagePollution * 300 * zoneMultiplier;

    // Add trend-based adjustment (ViT considers historical patterns)
    const trendAdjustment = Math.sin(Date.now() / 100000) * 15;

    return Math.max(0, Math.min(300, vitOutput + trendAdjustment));
}

/**
 * Fuses CNN and ViT predictions to get final AQI
 * Hybrid approach combines local (CNN) and global (ViT) insights
 * 
 * @param {Object} sensorData - Current sensor readings
 * @returns {Object} - Final AQI prediction with status
 */
function predictAQI(sensorData) {
    // Step 1: Get CNN prediction (local features)
    const cnnScore = cnnPrediction(sensorData);

    // Step 2: Get ViT prediction (global trends)
    const vitScore = vitPrediction(sensorData);

    // Step 3: Fusion - Combine both predictions
    // Weight: CNN 60% (local is important) + ViT 40% (global context)
    const fusionWeight = {
        cnn: 0.6,  // CNN gets more weight for immediate detection
        vit: 0.4   // ViT provides global context
    };

    const finalAQI = Math.round(
        (cnnScore * fusionWeight.cnn) +
        (vitScore * fusionWeight.vit)
    );

    // Step 4: Determine AQI status category
    let status;
    if (finalAQI <= 50) {
        status = 'GOOD';
    } else if (finalAQI <= 100) {
        status = 'MODERATE';
    } else if (finalAQI <= 150) {
        status = 'UNHEALTHY';
    } else if (finalAQI <= 200) {
        status = 'UNHEALTHY';
    } else {
        status = 'CRITICAL';
    }

    return {
        aqi: finalAQI,
        status: status,
        cnnScore: Math.round(cnnScore),
        vitScore: Math.round(vitScore),
        explanation: `CNN (local): ${Math.round(cnnScore)}, ViT (global): ${Math.round(vitScore)}`
    };
}

// Export the main prediction function
module.exports = { predictAQI, cnnPrediction, vitPrediction };
