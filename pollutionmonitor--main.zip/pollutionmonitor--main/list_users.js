const mongoose = require('mongoose');
const fs = require('fs');
require('dotenv').config();
const User = require('./src/models/User');

const listUsers = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        const users = await User.find({}, 'username email');
        const output = JSON.stringify(users, null, 2);
        fs.writeFileSync('all_users.txt', output);
        console.log('Users written to all_users.txt');
    } catch (error) {
        fs.writeFileSync('all_users.txt', 'Error: ' + error.message);
    } finally {
        await mongoose.disconnect();
        process.exit();
    }
};

listUsers();
