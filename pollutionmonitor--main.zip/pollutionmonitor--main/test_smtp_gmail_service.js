require('dotenv').config();
const nodemailer = require('nodemailer');
const fs = require('fs');

const log = (msg) => {
    console.log(msg);
    fs.appendFileSync('smtp_test_log_2.txt', msg + '\n');
};

const testSMTP = async () => {
    fs.writeFileSync('smtp_test_log_2.txt', '--- Starting SMTP Test 2 ---\n');
    log('--- Testing SMTP Connection (Service: Gmail) ---');
    log(`User: ${process.env.SMTP_USER}`);

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
        }
    });

    try {
        log('Verifying connection...');
        await transporter.verify();
        log('✅ Connection Verified!');

        log('Sending test email to sweetkiller281@gmail.com...');
        const info = await transporter.sendMail({
            from: process.env.FROM_EMAIL,
            to: 'sweetkiller281@gmail.com',
            subject: 'Test Email form Pollution App',
            text: 'If you see this, SMTP is working correctly.'
        });
        log(`✅ Email sent: ${info.messageId}`);
    } catch (error) {
        log(`❌ Error: ${error.message}`);
    }
};

testSMTP();
